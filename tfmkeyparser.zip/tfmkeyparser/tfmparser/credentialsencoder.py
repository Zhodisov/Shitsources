from .djbhash import djb_hash

from ctypes import c_int32
from typing import List

def cred_encoder(keys: List[int], key: str) -> List[int]:
    encrypted_keys = djb_hash(keys, key.encode(), len(key))

    if len(keys) < 2:
        keys.append(0)

    length = len(keys)
    i = keys[length - 1]
    j = keys[0]
    l = int(58 / length)

    m = 0
    for x in range(l):
        m += 2654435769
        l = m >>> 0x02 & 0x03

        for y in range(length):
            j = keys[y % length]
            l = (i >>> 5 ^ j << 2) + (j >>> 3 ^ i << 4) ^ (m ^ j) + (encrypted_keys[y & 0x03 ^ l] ^ i)

            i = keys[y] + l
            keys[y] += l

    return keys