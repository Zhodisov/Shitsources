from .regex import INT_METHOD, PUSH_NUM, find_one

from collections import defaultdict
from typing import List

class DataHandler:
	dumpscript: List[str] = []
	functions: defaultdict = defaultdict(int)

	def __init__(self, dumpscript: List[str]):
		DataHandler.dumpscript = dumpscript

	@classmethod
	async def extract_functions(cls):
		for line, content in enumerate(cls.dumpscript):
			if "method <q>[public]::int" in content and "0 params" in content:
				for x in range(20):
					if "returnvalue" in cls.dumpscript[line + x]:
						break
					push = await find_one(PUSH_NUM, cls.dumpscript[line + x])
					if push:
						cls.functions[(await find_one(INT_METHOD, content)).group(1)] += int(push.group(2))