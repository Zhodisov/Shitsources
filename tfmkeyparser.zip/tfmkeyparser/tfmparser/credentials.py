from .datahandler import DataHandler
from .regex import GET_PROPERTY, PUSH_STRING_2, find_one

from typing import Dict, List

class Credentials(dict):
	def __init__(self):
		self.dumpscript: List[str] = DataHandler.dumpscript

	async def fetch(self) -> Dict:
		self["credentials_key"] = []

		for line, content in enumerate(self.dumpscript):
			if "pushint 45103" in content:
				for x in range(line, line + 30):
					if "getproperty" in self.dumpscript[x]:
						getproperty = (await find_one(GET_PROPERTY, self.dumpscript[x])).group(2)
						for y in range(len(self.dumpscript)):
							if f"setproperty <q>[public]::{getproperty}" in self.dumpscript[y]:
								cred = await find_one(PUSH_STRING_2, self.dumpscript[y - 1])
								if cred is not None:
									self["credentials_key"].append(cred.group(1).encode().decode("unicode-escape"))
								break
					elif "callproperty <q>[public]flash.utils::getTimer" in self.dumpscript[x]:
						self["credentials_key"].append("timer")
		return self