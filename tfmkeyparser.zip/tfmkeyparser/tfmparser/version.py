from .datahandler import DataHandler
from .regex import INT_VALUE, find_one

from typing import Dict, List

class Version(dict):
	def __init__(self):
		self.dumpscript: List[str] = DataHandler.dumpscript

	async def fetch(self) -> Dict:
		for line, content in enumerate(self.dumpscript):
			if "returnvoid" in self.dumpscript[line - 3]:
				if "" in self.dumpscript[line - 1]:
					if ":<q>[public]::int =" in content:
						if ":<q>[public]::int =" in self.dumpscript[line + 1]:
							self["version"] = int((await find_one(INT_VALUE, content)).group(1))
							break
		return self