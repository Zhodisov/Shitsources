from .authkey import AuthKey
from .connectionkey import ConnectionKey
from .credentials import Credentials
from .datahandler import DataHandler
from .packetkeys import PacketKeys
from .serverip import ServerIP
from .swf import Swf
from .version import Version

from typing import Dict, List, Optional

import aiofiles
import aiohttp
import asyncio
import subprocess

loop = asyncio.get_event_loop()

class Parser:
	def __init__(self, is_local: bool = False, loop: Optional[asyncio.AbstractEventLoop] = None):
		self.loop: asyncio.AbstractEventLoop = loop or asyncio.get_event_loop()

		self.dumpscript: List = []
		self.fetched: Dict = {}

		self.is_local: bool = is_local

		self.last_swf_len: int = 0

		self.downloaded_swf: str = "Transformice.swf"
		self.output_swf: str = "tfm.swf"

	async def run_console(self, target: str):
		self.dumpscript *= 0

		console = subprocess.Popen(["tools/swfdump" if self.is_local else "swfdump", "-a", target], shell=False,
			stdin=subprocess.DEVNULL, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
		self.dumpscript = [line.decode().rstrip() for line in console.stdout]

		if target == self.output_swf:
			await self.loop.create_task(DataHandler(self.dumpscript).extract_functions())

	async def download_swf(self):
		update = False

		try:
			async with aiohttp.ClientSession() as session:
				async with session.get("https://www.transformice.com/Transformice.swf") as response:
					length = response.headers.get("Content-Length", 0)
					if length != self.last_swf_len:
						if response.status == 200:
							print("Downloading Transformice.swf")

							async with aiofiles.open(self.downloaded_swf, "w+b") as f:
								await f.write(await response.read())
							self.last_swf_len = length

							update = True
						else:
							self.last_swf_len = 0
		except Exception:
			print("Failed to download Transformice SWF")

		return update

	async def start(self):
		update = await self.download_swf()
		if update:
			try:
				await self.run_console(self.downloaded_swf)
				swf = Swf(self.downloaded_swf, self.output_swf)
				await swf.parse_content(self.dumpscript)
				await self.run_console(self.output_swf)
			except Exception:
				print("Failed to parse Transformice SWF")
			else:
				self.auth_key: AuthKey = AuthKey()
				self.connection_key: ConnectionKey = ConnectionKey()
				self.credentials_key: Credentials = Credentials()
				self.packet_keys: PacketKeys = PacketKeys()
				self.server_ip: ServerIP = ServerIP()
				self.version: Version = Version()

				names = ("auth_key", "connection_key", "credentials_key", "packet_keys", "server_ip", "version")
				for result in await asyncio.gather(*[(getattr(self, name)).fetch() for name in names]):
					self.fetched.update(result)

				print(self.fetched)

				print("Parser data has been updated")