from aiohttp import web
from tfmparser import Parser

from typing import Optional

import aiofiles
import asyncio
import json
import os

loop = asyncio.get_event_loop()

class Api:
	def __init__(self, loop: Optional[asyncio.AbstractEventLoop] = None):
		self.is_local: bool = "C:" in os.getcwd() or "D:" in os.getcwd()

		self.loop: asyncio.AbstractEventLoop = loop or asyncio.get_event_loop()
		self.parser: Parser = Parser(is_local=self.is_local)

	async def update(self):
		with open("./tokens.json") as f:
			self.tokens = json.load(f)
			
		self.loop.create_task(self.fetch())

	async def fetch(self):
		while True:
			await self.loop.create_task(self.parser.start())
			await asyncio.sleep(8)
		
	async def tfm_keys(self, request):
		token = request.query.get("token")
		response = {"success": False}
		status = 401

		if token is not None:
			if token in self.tokens:
				response["success"] = True
				response.update(self.parser.fetched)
				status = 200
			else:
				response["error"] = "unauthorized token"
		else:
			response["error"] = "token parameter missing"
			status = 400

		return web.json_response(response, status=status)

async def main():
	app = web.Application()
	endpoint = Api(loop)
	await endpoint.update()

	app.router.add_get("/tfm_keys", endpoint.tfm_keys)

	runner = web.AppRunner(app)
	await runner.setup()
	site = web.TCPSite(runner, "0.0.0.0", os.getenv("PORT"))
	await site.start()

if __name__ ==  "__main__":
	loop.create_task(main())
	loop.run_forever()