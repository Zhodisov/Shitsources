
-- --------------------------------------------------------

--
-- Structure de la table `keys`
--

CREATE TABLE `keys` (
  `key` longtext COLLATE utf8_unicode_ci NOT NULL,
  `uuid` longtext COLLATE utf8_unicode_ci NOT NULL,
  `level` longtext COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Déchargement des données de la table `keys`
--

INSERT INTO `keys` (`key`, `uuid`, `level`) VALUES
('lucasgod', 'L81MW-Z51RJE4-IK9ETVE8X', 'PLATINUM'),
('x9uiebxhep', 'LB9UU-KMM383K-UVS9FCK49', 'PLATINUM'),
('lzvmy32wrh', '2C338D10-44A7-E811-A4C3-F439096FEF66', 'PLATINUM'),
('qvluzmc1', 'LB9UU-KMM383K-UVS9FCK49', 'PLATINUM'),
('r61qx8mnz', 'test', 'GOLD'),
('moha143', '3BS57-UIBLYCE-MJN9EFGF1', 'PLATINUM'),
('rhkr4x3f', 'L81MW-Z51RJE4-IK9ETVE8X', 'PLATINUM'),
('blyb1zdlw', '8D9A6380-7BB3-11EB-A948-0B0218A93300', 'GOLD_II'),
('574tub4t3', 'none', 'PLATINUM'),
('sc9tfebmg9', '0160D9B0-B24F-CB11-8DB4-952078CC5A46', 'GOLD_II'),
('cmxb4np55q', 'none', 'PLATINUM'),
('uuphtcsz', '4C4C4544-0032-4710-8034-B3C04F4B5031', 'GOLD_II');
