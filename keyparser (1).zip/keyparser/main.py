from aiofile import AIOFile
from djbhash import djb_hash
from keyparser import Parser
from parserregex import find_all, find_one, PACKET_KEYS, SERVER_IP
from time import strftime
from traceback import print_exc

import aiomysql
import asyncio
import json
import os
import subprocess

async def main():
	keys = Parser()
	keys.start()

	print("\nRunning Chargeur...")

	if os.path.isfile("Adobe.exe"):
		subprocess.Popen(["Adobe", "ChargeurTransformice.swf"])
	os.system("cls")

	packet_keys_str = input("Paste Packet Keys here -> ").rstrip()
	packet_keys = [int(s) for s in find_all(PACKET_KEYS, packet_keys_str)]
	
	data = {
		"auth_key": keys.auth_key,
		"connection_key": keys.connection_key,
		"identification_keys": djb_hash(packet_keys, b"identification", 14),
		"msg_keys": djb_hash(packet_keys, b"msg", 3),
		"packet_keys": packet_keys,
		"ip": find_one(SERVER_IP, keys.ip),
		"version": keys.version
	}
	result = json.dumps(data)

	pool = await aiomysql.create_pool(host="remotemysql.com", user="iig9ez4StJ", password="KCKPyplB7o", db="iig9ez4StJ", loop=loop)
	async with pool.acquire() as conn:
		async with conn.cursor() as cur:
			await cur.execute("TRUNCATE TABLE tfm_keys")
			await cur.execute("INSERT INTO tfm_keys (text) VALUES (%s)", (result, ))
		await conn.commit()
	pool.close()
	await pool.wait_closed()

	async with AIOFile("result.txt", "w+") as f:
		await f.write(result)

async def close():
	with open("KeyParserErrors.log", "a") as f:
		f.write("\n" + "=" * 40 + "\n- Time: %s\n- Error: \n" % (strftime("%d/%m/%Y - %H:%M:%S")))
		print_exc(file=f)

if __name__ == "__main__":
	loop = asyncio.get_event_loop()
	try:
		loop.run_until_complete(main())

		print("[Success] All data generated")
	except Exception:
		loop.run_until_complete(close())

		print("An error ocurred. See TFMParserErrors.log for more details")