CALL_PROPERTY = r"callproperty <q>\[public\]::(.*?), (\d+) params$"
CALL_PROPERTY_2 = r"callproperty <q>\[(private|public)\](NULL|)::(.*?), 0 params"
EXPORT = r"(\s+)exports (\d+) as \"(.*?)_(.*?)\""
GET_PROPERTY = r"getproperty (.*?)::(.*?)$"
INIT_PROPERTY = r"initproperty <q>\[public\]::(.*)$"
INT_VALUE = r"int = (\d+)"
OBJECT = r"<q>\[public\]::Object <q>\[private\]NULL::(.*?)=\(\)\(0 params, 0 optional\)"
PACKET_KEYS = r",?(\d+)"
PUBLIC_METHOD = r"method <q>\[public\]::void <q>\[public\]::(.*?)=\(\)"
PUSH_NUM = r"push(byte|short|int) (-?\d+)$"
PUSH_STRING = r"pushstring \"(.*?)\"$"
PUSH_STRING_2 = r"findproperty <q>\[(private|public)\](NULL|)(.*?)\n(.*?)pushstring \"(.*?)\""
SERVER_IP = r"(.*?):"

import re
def find_one(regex, s):
    r = re.compile(regex)
    result = r.findall(s)
    if len(result) > 0:
        return result[0]
    return None

def find_all(regex, s):
    r = re.compile(regex)
    result = r.findall(s)
    if len(result) > 0:
        return result
    return None