from dumper import Swf #line:1
from parserregex import *#line:2
from collections import defaultdict #line:4
from urllib import request ,parse #line:5
import os #line:7
import shutil #line:8
import subprocess #line:9
class Parser :#line:11
	def __init__ (O00O000OOO0OO0OO0 ):#line:12
		O00O000OOO0OO0OO0 .chargeur_file =None #line:13
		O00O000OOO0OO0OO0 .game_len =None #line:14
		O00O000OOO0OO0OO0 .packet_keys_array_name =None #line:15
		O00O000OOO0OO0OO0 .pushes =defaultdict (int )#line:17
		O00O000OOO0OO0OO0 .dumpscript_list =[]#line:19
		O00O000OOO0OO0OO0 .connection_key =""#line:21
		O00O000OOO0OO0OO0 .download_swf ="tfm_download.swf"#line:22
		O00O000OOO0OO0OO0 .output_swf ="tfm.swf"#line:23
		O00O000OOO0OO0OO0 .ip = "51.75.130.180"
		O00O000OOO0OO0OO0 .auth_key =0 #line:25
		O00O000OOO0OO0OO0 .version =0 #line:26
	def delete_old_files (O00000O000OOOOO00 ):#line:28
		for OOOO0OO0000O00OOO in [O00000O000OOOOO00 .download_swf ,O00000O000OOOOO00 .output_swf ]:#line:29
			if os .path .exists (OOOO0OO0000O00OOO ):#line:30
				os .remove (OOOO0OO0000O00OOO )#line:31
	def decode_hash (OO0O00OO0OO00OOOO ,OOO000O0O0OO000O0 ,OO0O0OOO0OOO00000 ):#line:33
		OOOOO00000O0O0000 =OO0O00OO0OO00OOOO .read_swf (OO0O00OO0OO00OOOO .download_swf )#line:34
		O0000O0000OOOO0O0 ={}#line:36
		for O0OO00OOOOO00OOOO in find_all (EXPORT ,OOO000O0O0OO000O0 ):#line:37
			OOOOOO00OO0OOOO00 =int (O0OO00OOOOO00OOOO [1 ])#line:38
			_O0OO0OO000O00O0OO =O0OO00OOOOO00OOOO [3 ]#line:39
			O0000O0000OOOO0O0 [_O0OO0OO000O00O0OO ]=OOOOOO00OO0OOOO00 #line:40
		O0O0000O00OO0OO0O =find_all ("writeBytes({0})".format ("|".join (O0000O0000OOOO0O0 .keys ())),OO0O0OOO0OOO00000 )#line:41
		with open (OO0O00OO0OO00OOOO .output_swf ,"wb")as O00OOOOOO0O000OOO :#line:42
			O00OOOOOO0O000OOO .write (b"".join ([OOOOO00000O0O0000 [int (O0000O0000OOOO0O0 [O00O0OOO0O00O000O ])]for O00O0OOO0O00O000O in O0O0000O00OO0OO0O ]))#line:43
	def get_raw_name (O00O0O00O00O0000O ,O00O0000OO0OOOOOO ,to_swf =True ):#line:45
		O00O0000OO0OOOOOO =O00O0000OO0OOOOOO .encode ("unicode-escape").decode ().replace ("\\\\","\\")#line:46
		if to_swf :#line:47
			O00O0000OO0OOOOOO =O00O0000OO0OOOOOO .replace ("\\","\\x0")#line:48
		return O00O0000OO0OOOOOO #line:49
	def get_push_from_function (OOOOO00OOO0O0O0O0 ,OO0OOOOOOOO0O000O ):#line:51
		if OO0OOOOOOOO0O000O in OOOOO00OOO0O0O0O0 .pushes :#line:52
			return OOOOO00OOO0O0O0O0 .pushes [OO0OOOOOOOO0O000O ]#line:53
		for O0000O00OO000OO0O ,OOOO00OO000OO0O00 in enumerate (OOOOO00OOO0O0O0O0 .dumpscript_list ):#line:55
			if OO0OOOOOOOO0O000O +"=()(0 params, 0 optional)"in OOOO00OO000OO0O00 :#line:56
				for OO0000OO000OO0O0O in range (20 ):#line:57
					if "returnvalue"in OOOOO00OOO0O0O0O0 .dumpscript_list [O0000O00OO000OO0O +OO0000OO000OO0O0O ]:#line:58
						break #line:59
					OOO0000000O0O000O =find_one (PUSH_NUM ,OOOOO00OOO0O0O0O0 .dumpscript_list [O0000O00OO000OO0O +OO0000OO000OO0O0O ])#line:60
					if OOO0000000O0O000O :#line:61
						OOOOO00OOO0O0O0O0 .pushes [OO0OOOOOOOO0O000O ]+=int (OOO0000000O0O000O [1 ])#line:62
				break #line:63
		return OOOOO00OOO0O0O0O0 .pushes [OO0OOOOOOOO0O000O ]#line:64
	def find_crypto_keys (OOOO000OO00O00O00 ,OO00O0O0O0O0OO000 ,O0OO00O0O0O0O0OOO ):#line:66
		O00OO000OOO00OO00 ={}#line:67
		for OOOOOO0O000O000OO ,O0O0000OOOO00O0OO in enumerate (OO00O0O0O0O0OO000 ):#line:68
			if "<q>[public]::Object <q>[private]NULL::"in O0O0000OOOO00O0OO :#line:69
				O00000O0OO0O000O0 =find_one (OBJECT ,O0O0000OOOO00O0OO )#line:70
				if O00000O0OO0O000O0 is not None :#line:71
					O0OO00OO00OOO0O00 =find_one (PUSH_NUM ,OO00O0O0O0O0OO000 [OOOOOO0O000O000OO +6 ])#line:72
					if O0OO00OO00OOO0O00 is not None :#line:73
						O0OO00OO00OOO0O00 =int (O0OO00OO00OOO0O00 [1 ])#line:74
						O00OO000OOO00OO00 [O00000O0OO0O000O0 ]=O0OO00O0O0O0O0OOO [O0OO00OO00OOO0O00 ]#line:75
		return O00OO000OOO00OO00 #line:76
	def find_hash (OO00OO00000OO000O ,O00000000OO00OOO0 ):#line:78
		_O0OOO0OOO000O00O0 =find_one (PUSH_STRING_2 ,O00000000OO00OOO0 )#line:79
		if _O0OOO0OOO000O00O0 is not None :#line:80
			return (_O0OOO0OOO000O00O0 [2 ],_O0OOO0OOO000O00O0 [4 ])#line:81
		return ("","")#line:82
	def find_var_lines (O0O0OOO0O0OO0OOO0 ,OO0OOO0OOOO00OOOO ,O000000O00O0OOOO0 ):#line:84
		O00O0000O000OO0O0 =""#line:85
		for O00O0OOOOOO00OOO0 ,O0O0O0000O0O0OO0O in enumerate (OO0OOO0OOOO00OOOO ):#line:86
			if "getlocal_0"in O0O0O0000O0O0OO0O :#line:87
				OO0OOO0OO0OOOO0O0 =find_one (CALL_PROPERTY_2 ,OO0OOO0OOOO00OOOO [O00O0OOOOOO00OOO0 +1 ])#line:88
				if OO0OOO0OO0OOOO0O0 :#line:89
					O00O0000O000OO0O0 +=O000000O00O0OOOO0 [OO0OOO0OO0OOOO0O0 [2 ]]#line:90
		return O00O0000O000OO0O0 #line:91
	def parse_swf (O0OOO00OO0O00OOOO ):#line:93
		OOOO00O00O00O0O0O ="\n".join (O0OOO00OO0O00OOOO .dumpscript_list )#line:94
		if len (OOOO00O00O00O0O0O )>500000 :#line:95
			shutil .copyfile (O0OOO00OO0O00OOOO .output_swf ,O0OOO00OO0O00OOOO .download_swf )#line:96
		_OO00O0OO00OO00OOO ,OOOO000O0O0OO00OO =O0OOO00OO0O00OOOO .find_hash (OOOO00O00O00O0O0O )#line:98
		if len (OOOO000O0O0OO00OO )<16 :#line:99
			raise Exception ("Invalid crypto hash")#line:100
		O0OOO0000000O000O =O0OOO00OO0O00OOOO .find_crypto_keys (O0OOO00OO0O00OOOO .dumpscript_list ,OOOO000O0O0OO00OO )#line:101
		if len (O0OOO0000000O000O )<10 :#line:102
			raise Exception ("Invalid var keys")#line:103
		O0OOO00OO0O00OOOO .decode_hash (OOOO00O00O00O0O0O ,O0OOO00OO0O00OOOO .find_var_lines (O0OOO00OO0O00OOOO .dumpscript_list ,O0OOO0000000O000O ))#line:104
	def read_swf (O0OOOO00O0OO0OO0O ,OOOO000000O0O0O0O ):#line:106
		OOO0O000OO0000OO0 =Swf ()#line:107
		OOO0O000OO0000OO0 .read (OOOO000000O0O0O0O )#line:108
		OO0OO000O0OO0OO0O =False #line:110
		O0O0OO0OO0O0000O0 =1 #line:111
		O0O0000OOO0O00OOO ={}#line:113
		for O00O0OO0O0OO0O0OO in OOO0O000OO0000OO0 .tags :#line:114
			OOO0O00OO0O0OO000 =OOO0O000OO0000OO0 .tags [O00O0OO0O0OO0O0OO ]#line:115
			if "DefineBinaryData"in OOO0O00OO0O0OO000 [0 ]:#line:116
				OO0OO000O0OO0OO0O =True #line:117
				O0O0000OOO0O00OOO [O0O0OO0OO0O0000O0 ]=OOO0O00OO0O0OO000 [1 ][6 :]#line:118
			if OO0OO000O0OO0OO0O :#line:119
				O0O0OO0OO0O0000O0 +=1 #line:120
		return O0O0000OOO0O00OOO #line:121
	def run_console (OO0OOOO00OO0O0O0O ,OOOO0000O000OO0O0 ):#line:123
		OO0OOOO00OO0O0O0O .dumpscript_list *=0 #line:124
		O00OO0O000O0OOOO0 =subprocess .Popen (["Tools/swfdump","-a",OOOO0000O000OO0O0 ],shell =False,stdout=subprocess.PIPE, stderr=subprocess.STDOUT, stdin=subprocess.DEVNULL, creationflags=subprocess.CREATE_NO_WINDOW)#line:126
		if O00OO0O000O0OOOO0 is None :#line:127
			raise Exception ("Console not identified")#line:128
		for O000O000000000O0O in O00OO0O000O0OOOO0 .stdout :#line:129
			OO0OOOO00OO0O0O0O .dumpscript_list .append (O000O000000000O0O .rstrip ().decode ())#line:130
	def search_chargeur_folder (OO0000OOO0O000O00 ):#line:132
		O000O00O0O00O0O00 ="ChargeurTransformice-0/ChargeurTransformice_fla/MainTimeline.class.asasm"#line:133
		if not os .path .exists (O000O00O0O00O0O00 ):#line:134
			raise Exception ("ChargeurTransformice-0 folder not found")#line:135
		OO0000OOO0O000O00 .chargeur_file =O000O00O0O00O0O00 #line:136
	def start (OO00OO00O000000OO ):#line:138
		print ("Deleting old files...")#line:139
		OO00OO00O000000OO .delete_old_files ()#line:140
		print ("Downloading Transformice SWF...")#line:142
		import requests #line:144
		O000O000OO0O0OOOO =requests .get ("https://www.transformice.com/Transformice.swf",allow_redirects =True )#line:145
		with open (OO00OO00O000000OO .download_swf ,"wb")as OOO000O00OO000000 :#line:146
			OOO000O00OO000000 .write (O000O000OO0O0OOOO .content )#line:147
		print ("Reading SWF...")#line:149
		OO00OO00O000000OO .run_console (OO00OO00O000000OO .download_swf )#line:150
		print ("Rewriting SWF bytes...")#line:152
		OO00OO00O000000OO .parse_swf ()#line:153
		OO00OO00O000000OO .run_console (OO00OO00O000000OO .output_swf )#line:154
		print ("Parsing SWF data...")#line:156
		OO00OO00O000000OO .search_auth_key ()#line:157
		OO00OO00O000000OO .search_connection_key ()#line:158
		OO00OO00O000000OO .search_game_len ()#line:159
		OO00OO00O000000OO .search_packet_keys_array_name ()#line:160
		OO00OO00O000000OO .search_version ()#line:161
		OO00OO00O000000OO .search_ip ()
		print ("Loading Chargeur...")#line:163
		OO00OO00O000000OO .search_chargeur_folder ()#line:164
		print ("Writing Chargeur params...")#line:166
		OO00OO00O000000OO .update_chargeur_params ()#line:167
	def update_chargeur_params (O00000OOO000O000O ):#line:169
		OOOOO0O0000000O00 ,OOO0O0OOO0OOO00OO =None ,None #line:170
		OOO0O0OO0OOOOO0O0 =O00000OOO000O000O .read_lines (O00000OOO000O000O .chargeur_file )#line:172
		for OOOOO0O0O0000O000 ,OOOO0O0OO0OO0OOOO in enumerate (OOO0O0OO0OOOOO0O0 ):#line:173
			if "optional Utf8"in OOOO0O0OO0OO0OOOO :#line:174
				if "optional Utf8"in OOO0O0OO0OOOOO0O0 [OOOOO0O0O0000O000 +1 ]:#line:175
					OOOOO0O0000000O00 ,OOO0O0OOO0OOO00OO =OOOO0O0OO0OO0OOOO ,OOO0O0OO0OOOOO0O0 [OOOOO0O0O0000O000 +1 ]#line:176
					break #line:177
		if OOOOO0O0000000O00 is None or OOO0O0OOO0OOO00OO is None :#line:179
			raise Exception ('Fail on attempt to find params of "set_var_names" Function from Chargeur')#line:180
		O00O0OO0OO00OO00O ,O0OOOOOOOO0O0000O =O00000OOO000O000O .get_raw_name (O00000OOO000O000O .packet_keys_array_name ),O00000OOO000O000O .get_raw_name (O00000OOO000O000O .game_len )#line:182
		O0O000000O00O0O0O ="\n".join (OOO0O0OO0OOOOO0O0 )#line:184
		O0O000000O00O0O0O =O0O000000O00O0O0O .replace (OOOOO0O0000000O00 ,f'    optional Utf8("{O00O0OO0OO00OO00O}")')#line:185
		O0O000000O00O0O0O =O0O000000O00O0O0O .replace (OOO0O0OOO0OOO00OO ,f'    optional Utf8("{O0OOOOOOOO0O0000O}")')#line:186
		O00000OOO000O000O .write_file (O00000OOO000O000O .chargeur_file ,O0O000000O00O0O0O )#line:188
		os .system ("encryptchargeur")#line:190
	def search_ip (O0OO0O00O0O0O0O0O ):
		for O0O0OO0O0OO0000O0 ,OOOO0OO00OO0000O0 in enumerate (O0OO0O00O0O0O0O0O .dumpscript_list ):
			if "constructprop" in OOOO0OO00OO0000O0:
				if "pop" in O0OO0O00O0O0O0O0O .dumpscript_list [O0O0OO0O0OO0000O0 +1 ]:
					if "jump" in O0OO0O00O0O0O0O0O .dumpscript_list [O0O0OO0O0OO0000O0 +2 ]:
						if "getlex" in O0OO0O00O0O0O0O0O .dumpscript_list [O0O0OO0O0OO0000O0 +3 ]:
							if "pushtrue" in O0OO0O00O0O0O0O0O .dumpscript_list [O0O0OO0O0OO0000O0 +4 ]:
								if "callpropvoid" in O0OO0O00O0O0O0O0O .dumpscript_list [O0O0OO0O0OO0000O0 +5 ]:
									if "findpropstrict" in O0OO0O00O0O0O0O0O .dumpscript_list [O0O0OO0O0OO0000O0 +6 ]:
										if "pushstring" in O0OO0O00O0O0O0O0O .dumpscript_list [O0O0OO0O0OO0000O0 +7 ]:
											O0OO0O00O0O0O0O0O.ip = find_one (PUSH_STRING ,O0OO0O00O0O0O0O0O .dumpscript_list [O0O0OO0O0OO0000O0 +7 ])
											break
	def search_version (O0O00O0OOO000O00O ):#line:192
		for OOOO00O000O00OOO0 ,O0OO0000000O0O0OO in enumerate (O0O00O0OOO000O00O .dumpscript_list ):#line:193
			if "returnvoid"in O0O00O0OOO000O00O .dumpscript_list [OOOO00O000O00OOO0 -3 ]:#line:194
				if ""in O0O00O0OOO000O00O .dumpscript_list [OOOO00O000O00OOO0 -1 ]:#line:195
					if ":<q>[public]::int ="in O0OO0000000O0O0OO :#line:196
						if ":<q>[public]::int ="in O0O00O0OOO000O00O .dumpscript_list [OOOO00O000O00OOO0 +1 ]:#line:197
							OO0000OO0O00O00OO =int (find_one (INT_VALUE ,O0OO0000000O0O0OO ))#line:198
							if OO0000OO0O00O00OO <700 :#line:199
								O0O00O0OOO000O00O .version =OO0000OO0O00O00OO #line:200
							break #line:201
	def search_connection_key (O0OO0O00O0O0O0O0O ):#line:1
		OO0OOO0O00OOO0O0O =""#line:2
		for O0O0OO0O0OO0000O0 ,OOOO0OO00OO0000O0 in enumerate (O0OO0O00O0O0O0O0O .dumpscript_list ):#line:3
			if "getslot 7"in OOOO0OO00OO0000O0 :#line:4
				if "getlocal_0"in O0OO0O00O0O0O0O0O .dumpscript_list [O0O0OO0O0OO0000O0 +1 ]:#line:5
					if "getproperty"in O0OO0O00O0O0O0O0O .dumpscript_list [O0O0OO0O0OO0000O0 +2 ]:#line:6
						getproperty, add = "", 0
						if "getlex"in O0OO0O00O0O0O0O0O .dumpscript_list [O0O0OO0O0OO0000O0 +3 ]:#line:7
							if "getlex"in O0OO0O00O0O0O0O0O .dumpscript_list [O0O0OO0O0OO0000O0 +4 ]:#line:7:
								if "getproperty"in O0OO0O00O0O0O0O0O .dumpscript_list [O0O0OO0O0OO0000O0 +5 ]:#line:8
									getproperty = O0OO0O00O0O0O0O0O .dumpscript_list [O0O0OO0O0OO0000O0 +5 ]#line:8
									add = 2
							elif "getproperty"in O0OO0O00O0O0O0O0O .dumpscript_list [O0O0OO0O0OO0000O0 +4 ]:#line:8
								getproperty = O0OO0O00O0O0O0O0O .dumpscript_list [O0O0OO0O0OO0000O0 +4 ]#line:8
						if getproperty:
							if "getscopeobject 1"in O0OO0O00O0O0O0O0O .dumpscript_list [O0O0OO0O0OO0000O0 +5 + add]:#line:9
								if "getslot 8"in O0OO0O00O0O0O0O0O .dumpscript_list [O0O0OO0O0OO0000O0 +6 + add]:#line:10
									if "getlex"in O0OO0O00O0O0O0O0O .dumpscript_list [O0O0OO0O0OO0000O0 +7 + add]:#line:11
										if "callproperty"in O0OO0O00O0O0O0O0O .dumpscript_list [O0O0OO0O0OO0000O0 +8 + add]:
											OO0OOO0O00OOO0O0O =find_one (GET_PROPERTY , getproperty) [1 ]#line:14
											break #line:19
		if OO0OOO0O00OOO0O0O:
			for O0O0OO0O0OO0000O0 ,OOOO0OO00OO0000O0 in enumerate (O0OO0O00O0O0O0O0O .dumpscript_list ):#line:21
				if "findproperty <q>[public]::" + OO0OOO0O00OOO0O0O in OOOO0OO00OO0000O0 :#line:23
					if "pushstring"in O0OO0O00O0O0O0O0O .dumpscript_list [O0O0OO0O0OO0000O0 +1 ]:#line:24
						O0OO0O00O0O0O0O0O .connection_key =find_one (PUSH_STRING ,O0OO0O00O0O0O0O0O .dumpscript_list [O0O0OO0O0OO0000O0 +1 ])#line:25
						break
	def search_auth_key (O000000OOO0O0000O ):#line:223
		for OOOOOO0OO0000O00O ,O0000O00O0OOO00O0 in enumerate (O000000OOO0O0000O .dumpscript_list ):#line:224
			if "getlocal_0"in O0000O00O0OOO00O0 :#line:225
				if "convert_i"in O000000OOO0O0000O .dumpscript_list [OOOOOO0OO0000O00O +2 ]:#line:226
					if "setlocal_1"in O000000OOO0O0000O .dumpscript_list [OOOOOO0OO0000O00O +3 ]:#line:227
						for O00000000OO0O00O0 in range (100 ):#line:228
							if "getlocal_1"in O000000OOO0O0000O .dumpscript_list [OOOOOO0OO0000O00O +O00000000OO0O00O0 +3 ]:#line:229
								if "bitxor"in O000000OOO0O0000O .dumpscript_list [OOOOOO0OO0000O00O +O00000000OO0O00O0 +6 ]:#line:230
									if "callproperty"in O000000OOO0O0000O .dumpscript_list [OOOOOO0OO0000O00O +O00000000OO0O00O0 +5 ]:#line:231
										OO0O0O00OO0O00OOO =find_one (CALL_PROPERTY ,O000000OOO0O0000O .dumpscript_list [OOOOOO0OO0000O00O +O00000000OO0O00O0 +5 ])#line:232
										if OO0O0O00OO0O00OOO [1 ]=="0":#line:233
											O00000O000000OO0O =O000000OOO0O0000O .get_push_from_function (OO0O0O00OO0O00OOO [0 ])#line:234
											O000000OOO0O0000O .auth_key ^=O00000O000000OO0O #line:235
								if "lshift"in O000000OOO0O0000O .dumpscript_list [OOOOOO0OO0000O00O +O00000000OO0O00O0 +8 ]:#line:236
									if "callproperty"in O000000OOO0O0000O .dumpscript_list [OOOOOO0OO0000O00O +O00000000OO0O00O0 +5 ]:#line:237
										OO0O0O00OO0O00OOO =find_one (CALL_PROPERTY ,O000000OOO0O0000O .dumpscript_list [OOOOOO0OO0000O00O +O00000000OO0O00O0 +5 ])#line:238
										if OO0O0O00OO0O00OOO [1 ]=="0":#line:239
											OOOOO00O0O000OOO0 =O000000OOO0O0000O .get_push_from_function (OO0O0O00OO0O00OOO [0 ])#line:240
											if "callproperty"in O000000OOO0O0000O .dumpscript_list [OOOOOO0OO0000O00O +O00000000OO0O00O0 +5 ]:#line:241
												OO0O0O00OO0O00OOO =find_one (CALL_PROPERTY ,O000000OOO0O0000O .dumpscript_list [OOOOOO0OO0000O00O +O00000000OO0O00O0 +7 ])#line:242
												if OO0O0O00OO0O00OOO [1 ]=="0":#line:243
													OO00O0000O00000O0 =O000000OOO0O0000O .get_push_from_function (OO0O0O00OO0O00OOO [0 ])#line:244
													O000000OOO0O0000O .auth_key ^=OOOOO00O0O000OOO0 <<OO00O0000O00000O0 #line:245
							elif "returnvalue"in O000000OOO0O0000O .dumpscript_list [OOOOOO0OO0000O00O +O00000000OO0O00O0 +3 ]:#line:246
								break #line:247
	def search_packet_keys_array_name (OOOOOOO000OO00OO0 ):#line:249
		for OO000OO00OOO0O000 ,O00000O0OO000OO0O in enumerate (OOOOOOO000OO00OO0 .dumpscript_list ):#line:250
			if "=()(0 params, 0 optional)"in O00000O0OO000OO0O :#line:251
				if "getlocal_0"in OOOOOOO000OO00OO0 .dumpscript_list [OO000OO00OOO0O000 +5 ]:#line:252
					if "getproperty"in OOOOOOO000OO00OO0 .dumpscript_list [OO000OO00OOO0O000 +6 ]:#line:253
						if "getlocal_1"in OOOOOOO000OO00OO0 .dumpscript_list [OO000OO00OOO0O000 +7 ]:#line:254
							for OOO00OOOOOOOO0OO0 in range (25 ):#line:255
								if "flash.display:Sprite"in OOOOOOO000OO00OO0 .dumpscript_list [OO000OO00OOO0O000 +OOO00OOOOOOOO0OO0 +8 ]:#line:256
									OOOOOOO000OO00OO0 .packet_keys_array_name =find_one (GET_PROPERTY ,OOOOOOO000OO00OO0 .dumpscript_list [OO000OO00OOO0O000 +6 ])[1 ]#line:257
									break #line:258
							break #line:259
	def search_game_len (OOOO000OO0O0OOO00 ):#line:261
		for OO0OO0OO000O0OOOO ,O0O0OOO000OO0O0OO in enumerate (OOOO000OO0O0OOO00 .dumpscript_list ):#line:262
			if "stage"in O0O0OOO000OO0O0OO :#line:263
				if "loaderInfo"in OOOO000OO0O0OOO00 .dumpscript_list [OO0OO0OO000O0OOOO +1 ]:#line:264
					if "bytes"in OOOO000OO0O0OOO00 .dumpscript_list [OO0OO0OO000O0OOOO +2 ]:#line:265
						if "length"in OOOO000OO0O0OOO00 .dumpscript_list [OO0OO0OO000O0OOOO +3 ]:#line:266
							OOOO000OO0O0OOO00 .game_len =find_one (INIT_PROPERTY ,OOOO000OO0O0OOO00 .dumpscript_list [OO0OO0OO000O0OOOO +4 ])#line:267
							break #line:268
	def read_file (O00O00000O0OO0000 ,O0O0OOOOOOO0000OO ):#line:270
		O00O00OOOO0O0000O =O0O0OOOOOOO0000OO .replace ("\\x","%")#line:271
		with open (O00O00OOOO0O0000O ,"r+",encoding ="utf-8")as _O000OO0000OO0O00O :#line:272
			return _O000OO0000OO0O00O .read ()#line:273
		return None #line:274
	def read_lines (O0O000O000000O0O0 ,O0O0OO0OOOOOO0O00 ):#line:276
		return O0O000O000000O0O0 .read_file (O0O0OO0OOOOOO0O00 ).split ("\n")#line:277
	def write_file (O0O00OOOOOO00000O ,OO0OO0OOOOOO0OO0O ,O0OOO0O0O000O000O ):#line:279
		OOOO000000O000OOO =OO0OO0OOOOOO0OO0O .replace ("\\x","%")#line:280
		with open (OOOO000000O000OOO ,"w+")as _OO00O0O0O0O0OOO00 :#line:281
			_OO00O0O0O0O0OOO00 .write (str (O0OOO0O0O000O000O ))