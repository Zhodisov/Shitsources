from ctypes import c_int32

# Dan J. Bernstein's Hash Function https://medium.com/@khorvath3327/breaking-daniel-j-bernsteins-algorithm-2536e545d9c6
# This is a modified version of DJB Hash used in Transformice encryption (for Python)
def djb_hash(keys, s, s_len):
    buf = []

    hash = 5381    
    for i in range(20):
        hash = ((hash << 5) + hash) + (keys[i] + s[i % s_len])

    for i in range(20):
        hash ^= c_int32(hash).value << 13
        hash ^= c_int32(hash).value >> 17
        hash ^= c_int32(hash).value << 5
        buf.append(c_int32(hash).value)
        
    return buf