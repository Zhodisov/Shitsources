from .datahandler import DataHandler
from .djbhash import djb_hash
from .regex import CALL_PROPERTY, CALL_PROPVOID, CONSTRUCT_PROP, EXTENDS, FIND_PROPSTRICT, GET_LEX, \
	GET_PROPERTY, INIT_PROPERTY, OPERATOR, PUBLIC_METHOD, find_one

from typing import Dict, List, Optional, Tuple

class PacketKeys(dict):
	def __init__(self):
		self.functions: Dict[str, int] = DataHandler.functions

		self["packet_keys"] = [0] * 20
		self.dumpscript: List[str] = DataHandler.dumpscript
		self.generator_aliases: List[str] = []

		self.add_1: int = 0
		self.add_2: int = 0
		self.add_3: int = 0
		self.index: int = 0
		self.mod: int = 0
		self.sub: int = 0

		self.common_function: str = None

	def __iadd__(self, args):
		self["packet_keys"][args[(self.index + self.add_1) % self.mod] - self.sub] += args[(self.index + self.add_2) % self.mod]
		self.index += self.add_3
		return self

	async def get_params(self, line: int, params_nbr: int) -> List[int]:
		params = []

		for x in range(line, 0, -1):
			if "callproperty" in self.dumpscript[x]:
				push = self.functions[(await find_one(CALL_PROPERTY, self.dumpscript[x])).group(1)]
				if "negate" in self.dumpscript[x + 1]:
					push = -push
				params.insert(0, push)
			if len(params) == params_nbr:
				break

		return params

	async def find_calls(
		self,
		function_name: str,
		init_line: Optional[int] = 0,
		inner: Optional[List[str]] = None,
		instance: Optional[str] = None
	) -> Tuple[List[List[int]], int]:
		pushes = []
		return_line = 0

		for l in range(init_line, len(self.dumpscript)):
			if function_name + "=(" in self.dumpscript[l]:
				if instance is not None:
					found = False

					for j in range(l, 0, -1):
						if ") class" in self.dumpscript[j]:
							found = instance in self.dumpscript[j]
							break

					if not found:
						continue

				for n in range(l, len(self.dumpscript)):
					if "returnvoid" in self.dumpscript[n]:
						if self.dumpscript[n + 1].endswith("}"):
							return_line = n
							break

					if "callpropvoid" in self.dumpscript[n]:
						callpropvoid = await find_one(CALL_PROPVOID, self.dumpscript[n])
						if callpropvoid.group(1) in self.generator_aliases:
							params = await self.get_params(n, int(callpropvoid.group(2)))
							pushes.append(params)

					if inner:
						found_key = [key for key in inner if key in self.dumpscript[n]]
						if found_key:
							_pushes = None

							if "findpropstrict" in self.dumpscript[n]:
								findpropstrict = (await find_one(FIND_PROPSTRICT, self.dumpscript[n])).group(1)
								_pushes = (await self.find_calls(findpropstrict))[0]
							elif "callpropvoid" in self.dumpscript[n]:
								_inner, _instance = None, None

								if found_key[0] == "Initialisation":
									if "getlocal_0" not in self.dumpscript[n - 1]:
										continue
									_inner = [self.common_function] * 3
								elif found_key[0] == self.common_function:
									if "getlex" in self.dumpscript[n - 1]:
										getlex = await find_one(GET_LEX, self.dumpscript[n - 1])
										_instance = getlex.group(1)

								callpropvoid = await find_one(CALL_PROPVOID, self.dumpscript[n])
								_pushes = (await self.find_calls(
									callpropvoid.group(1), inner=_inner, instance=_instance,
								))[0]

							if _pushes:
								pushes.extend(_pushes)

							inner.remove(found_key[0])
				break

		return pushes, return_line

	async def fetch(self) -> Dict:
		generator_key, getproperty = "", ""
		return_line = 0

		for line, content in enumerate(self.dumpscript):
			if "=()(0 params, 0 optional)" in content:
				if "getlocal_0" in self.dumpscript[line + 5]:
					if "getproperty" in self.dumpscript[line + 6]:
						if "getlocal_1" in self.dumpscript[line + 7]:
							operators = []

							for x in range(line, len(self.dumpscript)):
								if "returnvoid" in self.dumpscript[x + 7]:
									break

								if "getlex" in self.dumpscript[x + 7]:
									if "callproperty" in self.dumpscript[x + 8]:
										operator_index = 11 if "getlocal_0" in self.dumpscript[x + 9] \
											else 9
										operator = await find_one(OPERATOR, self.dumpscript[x + operator_index])
										if operator is not None:
											operators.append(
												self.functions[(await find_one(CALL_PROPERTY, self.dumpscript[x + 8])).group(1)]
											)

							if len(operators) >= 5:
								self.add_1, self.mod, self.sub = operators[:3]
								self.add_2, self.add_3 = (operators[-3], operators[-1])

							generator_key = (await find_one(PUBLIC_METHOD, content)).group(1)
							break

		if generator_key:
			for line, content in enumerate(self.dumpscript):
				if "getproperty" in content and generator_key in content:
					if "initproperty" in self.dumpscript[line + 1]:
						self.generator_aliases.append((await find_one(INIT_PROPERTY, self.dumpscript[line + 1])).group(1))
						if len(self.generator_aliases) == 6:
							break

			for line, content in enumerate(self.dumpscript):
				if "callpropvoid" in content:
					callpropvoid = await find_one(CALL_PROPVOID, content)
					if callpropvoid.group(1) in self.generator_aliases:
						self += await self.get_params(line, int(callpropvoid.group(2)))

				elif "iffalse" in content:
					if "getlex" in self.dumpscript[line + 1]:
						if "constructprop" in self.dumpscript[line + 3]:
							constructprop = await find_one(CONSTRUCT_PROP, self.dumpscript[line + 3])
							for x in range(len(self.dumpscript)):
								if constructprop.group(1) in self.dumpscript[x] and "extends" in self.dumpscript[x]:
									parent = (await find_one(EXTENDS, self.dumpscript[x])).group(1)

									for y in range(len(self.dumpscript)):
										if parent + "=()" in self.dumpscript[y]:
											for z in range(y, len(self.dumpscript)):
												if "returnvoid" in self.dumpscript[z]:
													break
												if "getlex" in self.dumpscript[z] and "call" in self.dumpscript[z + 1]:
													function = (await find_one(CALL_PROPVOID, self.dumpscript[z + 1])).group(1)
													self.common_function = function
													calls = (await self.find_calls(
														function,
														z,
														instance=(await find_one(GET_LEX, self.dumpscript[z])).group(1))
													)[0]
													for keys in calls:
														self += keys
											break
									break

				elif "ADDED_TO_STAGE" in content:
					if "getproperty" in self.dumpscript[line + 2]:
						getproperty = (await find_one(GET_PROPERTY, self.dumpscript[line + 2])).group(2)
						break

			if getproperty:
				calls, return_line = await self.find_calls(getproperty)
				for keys in calls:
					self += keys

				inner = ["Initialisation"]

				for x in range(return_line, 0, -1):
					if "getproperty" in self.dumpscript[x]:
						getproperty = await find_one(GET_PROPERTY, self.dumpscript[x])
						for line, content in enumerate(self.dumpscript):
							if getproperty.group(2) + "=()" in content:
								for y in range(line, len(self.dumpscript)):
									if "constructprop" in self.dumpscript[y] and "pop" in self.dumpscript[y + 1]:
										inner.append((await find_one(CONSTRUCT_PROP, self.dumpscript[y])).group(1))
									elif "returnvoid" in self.dumpscript[y]:
										for z in range(y, 0, -1):
											if "callpropvoid" in self.dumpscript[z] and "getlocal_0" in self.dumpscript[z - 1]:
												inner.append((await find_one(CALL_PROPVOID, self.dumpscript[z])).group(1))
												break
										break

								calls = (await self.find_calls(getproperty.group(2), init_line=line, inner=inner))[0]
								for keys in calls:
									self += keys
								break
						break

		self["identification_keys"] = djb_hash(self["packet_keys"], b"identification", 14)
		self["msg_keys"] = djb_hash(self["packet_keys"], b"msg", 3)
		return self