from .datahandler import DataHandler
from .regex import PUSH_STRING_2, find_one

from typing import Dict, List

class ServerIP(dict):
	def __init__(self):
		self.dumpscript: List[str] = DataHandler.dumpscript

	async def fetch(self) -> Dict:
		for line, content in enumerate(self.dumpscript):
			if "jump" in content and "pushtrue" in self.dumpscript[line + 2] and "pushstring" in self.dumpscript[line + 5]:
				address = (await find_one(PUSH_STRING_2, self.dumpscript[line + 5])).group(1).split(":")
				self["server_ip"] = address[0]
				self["server_ports"] = list(map(int, address[1].split("-")))
				break
		return self