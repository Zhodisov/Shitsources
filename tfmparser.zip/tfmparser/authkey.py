from .datahandler import DataHandler
from .regex import CALL_PROPERTY, find_one

from typing import Dict, List

class AuthKey(dict):
	def __init__(self):
		self.dumpscript: List[str] = DataHandler.dumpscript
		self.functions: Dict[str, int] = DataHandler.functions
	
	async def fetch(self) -> Dict:
		self["auth_key"] = 0

		for line, content in enumerate(self.dumpscript):
			if "getlocal_0" in content:
				if "convert_i" in self.dumpscript[line + 2]:
					if "setlocal_1" in self.dumpscript[line + 3]:
						for x in range(100):
							if "getlocal_1" in self.dumpscript[line + x + 3]:
								if "bitxor" in self.dumpscript[line + x + 6]:
									if "callproperty" in self.dumpscript[line + x + 5]:
										callproperty = await find_one(CALL_PROPERTY, self.dumpscript[line + x + 5])
										if callproperty.group(2) == "0":
											self["auth_key"] ^= self.functions[callproperty.group(1)]
								if "lshift" in self.dumpscript[line + x + 8]:
									if "callproperty" in self.dumpscript[line + x + 5]:
										callproperty = await find_one(CALL_PROPERTY, self.dumpscript[line + x + 5])
										if callproperty.group(2) == "0":
											push = self.functions[callproperty.group(1)]
											if "callproperty" in self.dumpscript[line + x + 7]:
												callproperty = await find_one(CALL_PROPERTY, self.dumpscript[line + x + 7])
												if callproperty.group(2) == "0":
													self["auth_key"] ^= push << self.functions[callproperty.group(1)]
							elif "returnvalue" in self.dumpscript[line + x + 3]:
								return self
		return self