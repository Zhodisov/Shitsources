from .datahandler import DataHandler
from .regex import GET_PROPERTY, PUSH_STRING_2, find_one

from typing import Dict, List

class ConnectionKey(dict):
	def __init__(self):
		self.dumpscript: List[str] = DataHandler.dumpscript

	async def fetch(self) -> Dict:
		prop = ""

		for line, content in enumerate(self.dumpscript):
			if "getslot 7" in content:
				if "getlocal_0" in self.dumpscript[line + 1]:
					if "getproperty" in self.dumpscript[line + 2]:
						getproperty, add = "", 0

						if "getlex" in self.dumpscript[line + 3]:
							if "getlex" in self.dumpscript[line + 4]:
								if "getproperty" in self.dumpscript[line + 5]:
									getproperty = self.dumpscript[line + 5]
									add = 2
							elif "getproperty" in self.dumpscript[line + 4]:
								getproperty = self.dumpscript[line + 4]
						if getproperty:
							if "getscopeobject 1" in self.dumpscript[line + 5 + add]:
								if "getslot 8" in self.dumpscript[line + 6 + add]:
									if "getlex" in self.dumpscript[line + 7 + add]:
										if "callproperty" in self.dumpscript [line + 8 + add]:
											prop = (await find_one(GET_PROPERTY, getproperty)).group(2)
											break
		if prop:
			for line, content in enumerate(self.dumpscript):
				if "findproperty <q>[public]::" + prop in content:
					if "pushstring" in self.dumpscript[line + 1]:
						self["connection_key"] = (await find_one(PUSH_STRING_2, self.dumpscript[line + 1])).group(1)
						break

		return self