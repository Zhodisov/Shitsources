from aiotfm import Client, Connection, Packet
from aiotfm.enums import Community

from base64 import b64encode

import asyncio
import random

admins = ["Renangostoso#0000", "Nsouorenan#2576", "Luansantana#6873", "Tuggox#4348", "El_girafales#0612", "El_dauku#0634"]

class Bot(Client):
	def __init__(self, community=Community.br):
		super().__init__(community)

		self.farming = False
		self.win_task = None

		self.farm_mode = "racing"

	async def cancel_win_task(self):
		if self.win_task is not None:
			if not self.win_task.cancelled():
				self.win_task.cancel()
			self.win_task = None

	async def win(self):
		cheese_pos = self._room.map.cheese_pos
		for key in cheese_pos:
			await self.bulle.send(Packet.new(5, 19).write32(self._room.round_code).write16(key["X"]).write16(key["Y"]).write24(15))
			break

		hole_pos = self._room.map.hole_pos
		for key in hole_pos:
			hole_color = key["CT"] if "CT" in key else 0
			return await self.bulle.send(Packet.new(5, 18).write8(hole_color).write32(self._room.round_code).write32(self._room.map.code).write16(15).write16(key["X"]).write16(key["Y"]))

	async def move(self):
		packet = Packet.new(4, 4).write32(self._room.round_code)
		packet.writeBool(True).writeBool(False)
		packet.write32(400).write32(200)
		packet.write16(0).write16(0)
		packet.writeBool(True)
		packet.write8(0).write8(0)
		await self.bulle.send(packet)

	async def mort(self):
		await self.bulle.send(Packet.new(4, 5).write32(self._room.round_code).write8(0))

	async def play_map(self):
		await asyncio.sleep(3)
		await self.move()
		await asyncio.sleep(2)
		await self.win()
		await asyncio.sleep(.01)

	async def on_ready(self):
		print("Connected account: " + self.username)

	async def on_joined_room(self, room):
		print("Joined room: " + room.name)

		await self.sendCommand("pw &&&&&&")
		
	async def on_tribe_inv(self, author, tribe):
		if author.capitalize() in admins:
			print(f"{author} invited to {tribe} tribe house")

			self.no_bulle = False
			self.farming = False

			await self.enterInvTribeHouse(author)

	async def on_player_update(self, _, player):
		if self.farming:
			if self.farm_mode == "bootcamp":
				if self.username == player.username:
					self.win_task = asyncio.ensure_future(self.play_map())

	async def on_map_change(self, new_map):
		if not self.farming:
			return
		if not new_map.xml:
			return await self.mort()
		if self.farm_mode == "bootcamp":
			await self.cancel_win_task()
			await self.mort()
		elif self.farm_mode == "racing":
			await self.cancel_win_task()

			self.win_task = asyncio.ensure_future(self.play_map())
		elif self.farm_mode == "move":
			await asyncio.sleep(3)
			await self.move()
			await self.mort()

client = Bot()

@client.command
async def house(ctx, *a):
	if str(ctx.author) in admins:
		client.farming = False
		client.no_bulle = False

		await client.enterTribe()

@client.command
async def room(ctx, *a):
	if str(ctx.author) in admins:
		client.farming = False
		client.no_bulle = False

		await client.joinRoom(" ".join([*a]))

@client.command
async def nroom(ctx, *a):
	if str(ctx.author) in admins:
		client.no_bulle = True
		await client.joinRoom(" ".join([*a]))

		conn, packet = await client.wait_for("on_raw_socket")
		if conn.name == "main":
			if packet.readCode() == (44, 1):
				client.farming = True

				timestamp = packet.read32()
				uid = packet.read32()
				pid = packet.read32()
				bulle_ip = packet.readUTF()
				ports = packet.readUTF().split('-')

				print(f"bulle_ip2: {bulle_ip}, bulle_tstamp2: {timestamp}")

				await asyncio.sleep(3)
				await client.joinRoom(
					"#fortmice66\u200B\u200B\u200B\u200B",
					password="&&&&&&"
				)

				client.bulle = Connection('bulle', client, client.loop)
				await client.bulle.connect(bulle_ip, int(random.choice(ports)))
				await client.bulle.send(Packet.new(44, 1).write32(timestamp).write32(uid).write32(pid))

@client.command
async def sroom(ctx, *a):
	if str(ctx.author) in admins:
		client.farming = True
		client.no_bulle = False

		await client.joinRoom(
			" ".join([*a]) + "\u200B\u200B\u200B\u200B",
			password="&&&&&&"
		)

@client.command
async def start(ctx, *a):
	if str(ctx.author) in admins:
		client.farming = True

@client.command
async def stop(ctx, *a):
	if str(ctx.author) in admins:
		client.farming = False

loop = asyncio.get_event_loop()
loop.create_task(client.start(
	b64encode("9eib1q8l".encode()).decode(),
	username="Account#tag",
	password="password",
	encrypted=False,
	room="*#records0bot"
))
loop.run_forever()